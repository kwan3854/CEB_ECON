pytorch3d.implicitron.dataset in general
========================================

Basics of data for implicitron

.. automodule:: pytorch3d.implicitron.dataset.dataset_base
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.dataset_map_provider
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.data_loader_map_provider
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.data_source
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.scene_batch_sampler
    :members:
    :undoc-members:
    :show-inheritance:
