pytorch3d.implicitron.dataset specific datasets
===============================================

specific datasets

.. automodule:: pytorch3d.implicitron.dataset.blender_dataset_map_provider
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.json_index_dataset_map_provider
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.json_index_dataset_map_provider_v2
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.llff_dataset_map_provider
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.dataset.rendered_mesh_dataset_map_provider
    :members:
    :undoc-members:
    :show-inheritance:
