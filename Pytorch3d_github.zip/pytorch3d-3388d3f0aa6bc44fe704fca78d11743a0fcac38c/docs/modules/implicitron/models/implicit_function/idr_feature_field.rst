pytorch3d.implicitron.models.implicit_function.idr_feature_field
================================================================

idr_feature_field

.. automodule:: pytorch3d.implicitron.models.implicit_function.idr_feature_field
    :members:
    :undoc-members:
    :show-inheritance:
