pytorch3d.implicitron.models.feature_extractor
==============================================

.. toctree::

    feature_extractor
    resnet_feature_extractor
