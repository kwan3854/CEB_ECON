pytorch3d.implicitron.models.feature_extractor.resnet_feature_extractor
=======================================================================

resnet_feature_extractor

.. automodule:: pytorch3d.implicitron.models.feature_extractor.resnet_feature_extractor
    :members:
    :undoc-members:
    :show-inheritance:
