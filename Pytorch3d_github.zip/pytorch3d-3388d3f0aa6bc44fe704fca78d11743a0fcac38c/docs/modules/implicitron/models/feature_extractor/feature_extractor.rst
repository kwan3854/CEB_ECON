pytorch3d.implicitron.models.feature_extractor.feature_extractor
================================================================

feature_extractor

.. automodule:: pytorch3d.implicitron.models.feature_extractor.feature_extractor
    :members:
    :undoc-members:
    :show-inheritance:
