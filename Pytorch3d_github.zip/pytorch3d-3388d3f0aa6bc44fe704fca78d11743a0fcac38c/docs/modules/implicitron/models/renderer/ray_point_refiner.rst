pytorch3d.implicitron.models.renderer.ray_point_refiner
=======================================================

ray_point_refiner

.. automodule:: pytorch3d.implicitron.models.renderer.ray_point_refiner
    :members:
    :undoc-members:
    :show-inheritance:
