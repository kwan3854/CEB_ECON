pytorch3d.implicitron.models.renderer.ray_sampler
=================================================

ray_sampler

.. automodule:: pytorch3d.implicitron.models.renderer.ray_sampler
    :members:
    :undoc-members:
    :show-inheritance:
