pytorch3d.implicitron.models.model_dbir
=======================================

model_dbir

.. automodule:: pytorch3d.implicitron.models.model_dbir
    :members:
    :undoc-members:
    :show-inheritance:
