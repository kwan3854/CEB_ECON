pytorch3d.implicitron.models.view_pooler.view_sampler
=====================================================

view_sampler

.. automodule:: pytorch3d.implicitron.models.view_pooler.view_sampler
    :members:
    :undoc-members:
    :show-inheritance:
