pytorch3d.implicitron.evaluation
================================

evaluation

.. automodule:: pytorch3d.implicitron.evaluation.evaluate_new_view_synthesis
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pytorch3d.implicitron.evaluation.evaluator
    :members:
    :undoc-members:
    :show-inheritance:
