pytorch3d.renderer.mesh.shading
===============================

shading

.. automodule:: pytorch3d.renderer.mesh.shading
    :members:
    :undoc-members:
    :show-inheritance:
