pytorch3d.renderer.mesh.clip
============================

clip

.. automodule:: pytorch3d.renderer.mesh.clip
    :members:
    :undoc-members:
    :show-inheritance:
