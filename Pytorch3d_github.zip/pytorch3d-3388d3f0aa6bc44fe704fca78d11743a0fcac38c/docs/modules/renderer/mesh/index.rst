pytorch3d.renderer.mesh
=======================

.. toctree::

    clip
    rasterize_meshes
    rasterizer
    renderer
    shader
    shading
    textures
    utils
