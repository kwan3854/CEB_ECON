pytorch3d.renderer.implicit.sample_pdf
======================================

sample_pdf

.. automodule:: pytorch3d.renderer.implicit.sample_pdf
    :members:
    :undoc-members:
    :show-inheritance:
