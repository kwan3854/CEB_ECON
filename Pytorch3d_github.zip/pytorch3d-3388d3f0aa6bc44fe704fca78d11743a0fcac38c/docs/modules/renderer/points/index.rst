pytorch3d.renderer.points
=========================

.. toctree::

    compositor
    rasterize_points
    rasterizer
    renderer
    pulsar/index
