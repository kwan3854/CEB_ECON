pytorch3d.renderer.points.compositor
====================================

compositor

.. automodule:: pytorch3d.renderer.points.compositor
    :members:
    :undoc-members:
    :show-inheritance:
