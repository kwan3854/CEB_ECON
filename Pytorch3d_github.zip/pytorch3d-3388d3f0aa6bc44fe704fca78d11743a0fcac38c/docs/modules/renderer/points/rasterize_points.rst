pytorch3d.renderer.points.rasterize_points
==========================================

rasterize_points

.. automodule:: pytorch3d.renderer.points.rasterize_points
    :members:
    :undoc-members:
    :show-inheritance:
