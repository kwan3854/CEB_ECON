pytorch3d.renderer.points.renderer
==================================

renderer

.. automodule:: pytorch3d.renderer.points.renderer
    :members:
    :undoc-members:
    :show-inheritance:
