pytorch3d.renderer.points.rasterizer
====================================

rasterizer

.. automodule:: pytorch3d.renderer.points.rasterizer
    :members:
    :undoc-members:
    :show-inheritance:
