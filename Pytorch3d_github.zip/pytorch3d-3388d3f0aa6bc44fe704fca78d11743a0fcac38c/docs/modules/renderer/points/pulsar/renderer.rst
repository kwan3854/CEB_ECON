pytorch3d.renderer.points.pulsar.renderer
=========================================

renderer

.. automodule:: pytorch3d.renderer.points.pulsar.renderer
    :members:
    :undoc-members:
    :show-inheritance:
